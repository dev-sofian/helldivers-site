/// Installation ///

1. Extract zip file.
2. Copy/paste all OTF files to C:\Windows\Fonts
3. Enjoy.

/// Description ///

"FS Sinclair Medium" is mainly used for UI in Helldivers II, especially the name plate of your Super Destroyer ship. "FS Sinclair Regular" is optional one.
And "Swiss 721 Extended Bold" is for the name of planets placed at top-left of screen during the cutscenes and loading screen.

All of these fonts were downloaded from different sites that shares free fonts.